# Suffolk Cricket Cub Hub — standalone website starter

A runnable Next.js website with a public Cub Hub homepage, email magic-link parent sign-in, a guardian-only dashboard, and Supabase row-level security SQL. Based on the Suffolk Cricket blue/gold design and the 2026 paper observation categories.

## Status and limitations

**This is a starter, not a production-ready child-data portal.** The public site and guardian-read pathway are implemented, but it has NOT been deployed, security-tested or approved for real children's data. Staff Excel/CSV upload, staff review/publish screens, per-child PDF generation, guardian verification administration, report storage, audit logs, account recovery and full operational controls are not implemented. Do not upload real player records until these are built, independently tested and approved.

## Local setup

1. Install Node.js 20+ and run `npm install` in this folder.
2. Create a Supabase project under a Suffolk Cricket-approved organisation/account.
3. In Supabase SQL Editor, run `supabase/schema.sql` after review by your developer.
4. Copy `.env.example` to `.env.local` and fill the project URL and **publishable/anon** key. Never put a service-role key in NEXT_PUBLIC variables or the repository.
5. Configure Supabase Auth email OTP / magic links and add `http://localhost:3000/auth/callback` to allowed redirect URLs. For production, add your approved HTTPS domain callback URL. Disable unapproved self-signup/invitations if appropriate and configure an approved mail sender.
6. Run `npm run dev`, then open http://localhost:3000.
7. For the live site, deploy to an approved hosting provider, configure HTTPS, environment variables, domain DNS and Supabase redirect URLs.

## Parent access

Parent logs in by email; their Supabase Auth user ID is linked to a player in `guardian_player_links` by trusted staff after verification. Only `verified=true` links can read players. Only `status='published'` assessments are visible. No browser/client insert/update policies are provided. Revoking a link blocks new reads. Test this thoroughly with two unrelated parent accounts and multiple children before launch.

## Important implementation work before go-live

- Confirm whether coach form is 1–5 or 1–6; this starter enforces 1–5.
- Add an administrator-only CSV import that validates player IDs, score range, duplicate periods, missing observations and comment lengths; stage and preview before approval.
- Compute averages on the server from observed criteria, with observation counts; do not accept user-provided averages as authoritative.
- Add approval workflow and report PDF generator based on the two-page report template; use private storage and authenticated download endpoints.
- Add MFA for staff, security logs, backup/restore tests, rate limiting, content security policy, vulnerability updates and a tested account-revocation process.
- Confirm UK GDPR lawful basis, safeguarding requirements, privacy notice, processor contracts, international transfers, retention/deletion schedule and incident response with Suffolk Cricket.
- Review accessibility, mobile behaviour and report comprehensibility with a small parent pilot.
- Do not claim this is an official Suffolk Cricket service or use its logo without organisational approval.

## Intended first release

Public homepage → parent sign-in → linked child dashboard → published assessments → downloadable individual PDFs. The current code implements the first three stages and read-only assessment summaries; PDF download and admin workflows are future development.
