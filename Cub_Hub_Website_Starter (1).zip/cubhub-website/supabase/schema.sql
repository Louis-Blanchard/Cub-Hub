-- Run in a NEW Supabase project, after approval from Suffolk Cricket's data protection lead.
-- No public insert/update policies are granted: data is entered only by trusted staff using
-- controlled administrative processes, not by browser clients or parents.
create extension if not exists pgcrypto;
create table public.players (
 id uuid primary key default gen_random_uuid(),
 external_player_id text unique not null,
 first_name text not null,
 last_name text not null,
 age_group text not null check (age_group in ('U9','U10','U11','U12')),
 venue text,
 created_at timestamptz not null default now()
);
create table public.guardian_player_links (
 guardian_user_id uuid not null references auth.users(id) on delete cascade,
 player_id uuid not null references public.players(id) on delete cascade,
 verified boolean not null default false,
 verified_at timestamptz,
 primary key (guardian_user_id, player_id)
);
create table public.assessments (
 id uuid primary key default gen_random_uuid(),
 player_id uuid not null references public.players(id) on delete cascade,
 period_label text not null,
 status text not null default 'draft' check (status in ('draft','reviewed','published')),
 published_at timestamptz,
 batting_average numeric(3,2) check (batting_average between 1 and 5),
 bowling_average numeric(3,2) check (bowling_average between 1 and 5),
 fielding_average numeric(3,2) check (fielding_average between 1 and 5),
 strength text,
 next_step_1 text,
 next_step_2 text,
 coach_message text,
 unique(player_id,period_label),
 constraint published_requires_date check (status <> 'published' or published_at is not null)
);
create table public.assessment_scores (
 assessment_id uuid not null references public.assessments(id) on delete cascade,
 criterion_code text not null check (criterion_code in (
 'bat_setup','bat_head','bat_face','bat_execution','bat_selection',
 'bowl_grip','bowl_runup','bowl_safe','bowl_consistency','bowl_spin',
 'field_ready','field_movement','field_ground','field_catching','field_throwing','coachability')),
 score smallint check (score between 1 and 5),
 primary key(assessment_id,criterion_code)
);
create index on public.guardian_player_links(guardian_user_id) where verified=true;
create index on public.assessments(player_id,status);
alter table public.players enable row level security;
alter table public.guardian_player_links enable row level security;
alter table public.assessments enable row level security;
alter table public.assessment_scores enable row level security;
-- Guardian links are administered by trusted staff. No guardian can create or verify a link.
create policy guardian_sees_own_links on public.guardian_player_links
 for select to authenticated using (guardian_user_id=(select auth.uid()) and verified=true);
create policy guardian_sees_linked_player on public.players
 for select to authenticated using (exists(
 select 1 from public.guardian_player_links g where g.player_id=players.id
 and g.guardian_user_id=(select auth.uid()) and g.verified=true));
create policy guardian_sees_published_assessment on public.assessments
 for select to authenticated using (status='published' and exists(
 select 1 from public.guardian_player_links g where g.player_id=assessments.player_id
 and g.guardian_user_id=(select auth.uid()) and g.verified=true));
create policy guardian_sees_published_scores on public.assessment_scores
 for select to authenticated using (exists(
 select 1 from public.assessments a join public.guardian_player_links g on g.player_id=a.player_id
 where a.id=assessment_scores.assessment_id and a.status='published'
 and g.guardian_user_id=(select auth.uid()) and g.verified=true));
-- Default-deny all client writes: service-role/admin writes must be implemented on a protected backend.
revoke all on public.players,public.guardian_player_links,public.assessments,public.assessment_scores from anon;
grant select on public.players,public.guardian_player_links,public.assessments,public.assessment_scores to authenticated;
